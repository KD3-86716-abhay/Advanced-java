package com.sunbeam.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sunbeam.daos.UserDao;
import com.sunbeam.daos.UserDaoImpl;
import com.sunbeam.entities.User;

@WebServlet("/signUp")
public class NewUser extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp);
	}
	
	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Register</title>");
		out.println("</head>");
		out.println("<body>");
		out.println();
		
		String firstname=req.getParameter("fname");
		String lastname=req.getParameter("lname");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		String DateofBirth=req.getParameter("dob");
		Date d=Date.valueOf(DateofBirth);
//		int status=0;
		User u=new User(0,firstname,lastname,email,password,d,0,"voter");
		try(UserDao userDao=new UserDaoImpl()){
			userDao.save(u);
	
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
		
		out.println();
		out.println("<p><a href='index.html'>Login Again</a></p>");
		out.println("</body>");
		out.println("</html>");
		
	}
}
