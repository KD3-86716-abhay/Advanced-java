package com.sunbeam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>ProfileServlet</title>");
		out.println("</head>");
		out.println("<body style=background-color:pink>");
		out.println("<h1>This is Profile Servlet page</h1>");
		out.println("<h2>FirstName:abhay</h2>");
		out.println("<h2>lastName:siddheshware</h2>");
		out.println("<h2>Qualification:B.E</h2>");
		out.println("<h2>Birthdate:10/12/2002</h2>");
		out.println("</body>");
		out.println("</html>");
		
	}	
}
