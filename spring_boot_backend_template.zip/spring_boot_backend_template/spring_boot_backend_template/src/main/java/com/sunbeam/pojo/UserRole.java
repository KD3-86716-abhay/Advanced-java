package com.sunbeam.pojo;

public enum UserRole {
ADMIN,CUSTOMER
}
